<?php

use Illuminate\Support\Facades\Route;
use App\Models\Makanan;
use App\Http\Controllers\BuyController;


Route::get('/', function () {
    return redirect()->route('about');
});
Route::get('/about', function () {
    return view('about');
})->name('about');
Route::get('/buy', function () {
    $makanan = Makanan::all();
    return view('buy', compact('makanan'));
})->name('buy');
Route::get('/contact', function () {
    return view('contact');
})->name('contact');
Route::get('/list', function () {
    return view('list');
})->name('list');
Route::post('/buy/process', [BuyController::class, 'process'])->name('buy.process');




