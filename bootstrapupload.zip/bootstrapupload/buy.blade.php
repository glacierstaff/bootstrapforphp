<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Kantin SMK Telkom Jakarta</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
  <style>
    
    body {
      margin: 0;
      padding: 0;
      width: 100%;
      height: 100%;
    }
    iframe {
      width: 100vw;
      height: 100vh;
      border: none;
    }
    .main-panel-sect {
      background: #ff150d;
      position: fixed;
      bottom: 0;
      width: 100%;
      padding: 10px 0;
      display: none;
    }
    .main-panel-sect-inner {
      max-width: 600px;
      margin: 0 auto;
      text-align: center;
    }
    a.view-code, a.view-more {
      background: #ff150d;
      color: #fff;
      padding: 8px;
      font-size: 14px;
      border-radius: 10px;
      box-shadow: 0 0 10px #0000008a;
      margin-left: 10px;
      float: left;
    }
    * {
	margin:0px;
	padding:0px;
}
body, html {
	font-family: Roboto, sans-serif, arial;
	background:#f0f3fa
}
.width-100 {
	width:100%;
	float:left;
}
.width-20 {
	width:20%;
	float:left;
}
.width-25 {
	width:25%;
	float:left;
}
.width-30 {
	width:30%;
	float:left;
}
.width-33 {
	width:33%;
	float:left;
}
.width-40 {
	width:40%;
	float:left;
}
.width-50 {
	width:50%;
	float:left;
}
.width-60 {
	width:60%;
	float:left;
}
.width-70 {
	width:70%;
	float:left;
}
.width-80 {
	width:80%;
	float:left;
}
.width-90 {
	width:90%;
	float:left;
}
.width-10 {
	width:10%;
	float:left;
}
.container {
	width:1500px;
	margin:0 auto;
}
.plr {
	padding-left:100px;
	padding-right:100px;
}
.margin-top-50 {
	margin-top:50px;
}
/* Header 1 STARTS */

.top-header {
	background:red;
	padding:5px 0px;
	border-bottom: 1px solid #3131315e;
}
.news-list {
	background: #fff;
	color: red;
	padding: 6px;
	font-size: 20px;
}
.headquote {
	font-size:18px;
	color:#ffffff;
	width:80%;
}
/* Header 1 ENDS */

/* Header 3 STARTS */
.header-menu {
	position: fixed;
	box-shadow: 0px 2px 5px 0px #00000036;
  top: 0;
  background: white;
}
.logo {
	width: fit-content;
	float: left;
  margin: 5px 5px 5px 5px;
}
.main-menu {
	list-style:none;
	float:right;
	margin-top: 20px;
}
.main-menu a {
	font-weight: 500;
	color: #3a3a3a;
	font-size: 20px;
	text-decoration: none;
}
.main-menu li {
	float:left;
	padding:12px 15px;
}
.slider-width{
	width:100%;
	height: 100%;
  margin-top: 5%;
}
/* Header 3 ENDS */

/* Information section STARTS */
.latest-news{
	margin-left:10px;
	margin-right:10px;
	background:#fff;
	padding:20px;
	height:350px;
	margin-bottom:30px;
	
	
}
.event-list{
	margin-left:10px;
	margin-right:10px;
	background:#fff;
	padding:20px;
	height:400px;
	margin-bottom:30px;
	
	
}
.notice-board{
	margin-left:10px;
	margin-right:10px;
	background:#fff;
	padding:20px;
	height:350px;
	margin-bottom:30px;
	
	
}
.our-principal{
	margin-left:10px;
	margin-right:10px;
	background:#fff;
	padding:20px;
	height:350px;
	margin-bottom:30px;
	
	
}
.about-us{
	margin-left:10px;
	margin-right:10px;
	background:#fff;
	padding:20px;
	height:350px;
	margin-bottom:30px;
	
	
}
.certificate{
	margin-left:10px;
	margin-right:10px;
	background:#fff;
	padding:20px;
	height:350px;
	margin-bottom:30px;
	
	
}
.heading-sect{
    width: 100%;
    float: left;
    border-bottom: 1px solid #cfcfcf;
    padding-bottom: 0px;
    margin: 0px;
    margin-bottom: 15px;
    padding-top: 2px;
	    border: 1px solid #cfcfcf;
    padding-bottom: 10px;
    padding-top: 15px;
    padding-left: 15px;
    background: red;
	color:white;
}
.heading-sect h3{
	color:white;
}
.head-title {
    margin: 0px;
    padding: 0px;
    font-size: 16px;
    font-weight: 600;
    font-family: 'Roboto', sans-serif!important;
    color: red;
    padding-bottom: 5px;
}
.upcoming-event-list li {
    width: 100%;
    float: left;
    margin-bottom: 10px;
    margin-left: 5px;
}
.upcoming-event-list{
padding:0px;
list-style:none;
}
.event-date {
    background: red;
    width: 150px;
    float: left;
    text-align: center;
    font-size:14px;
    color: #fff;
    padding:8px;
	margin-right: 10px;
    margin-top: 2px;
    margin-bottom: 2px;
    height: 125px;
}


.notice-board-list li {
    width: 100%;
    float: left;
    margin-bottom: 15px;
}
.notice-board-list{
padding:0px; list-style:none;
}
.latest-news-ul{
	padding:0px;list-style:none;line-height: 40px;
}
/* Information section ENDS */

/* BANNER SECTION STARTS */
.useful-info-ul{
	list-style:none;
}
.useful-info-ul a{
	text-decoration:none;
	color:black;
	font-weight:bold;
}
.useful-info-ul li{
	margin-bottom:15px;
	    border-bottom: 1px solid #d7d7d7;
    padding-bottom: 15px;
}
.principal-image{
	text-align:center
}
.principal-image img{
	height:230px;
}
.principal-para{
	font-weight:bold;
}

/* BANNER SECTION ENDS */

/* GALLERY SECTION STARTS */
.gallery-img{
	height:250px;
	width:100%;
}
.governor-img{
width:100%;
}
.governor-name{
    font-size: 16px;
    color: black;
    font-weight: bold;
    padding-left: 10px;
    margin-top: 20px;
}
.governor-designation{
font-size: 15px;
    color: black;
    padding-left: 10px;
    margin-top: 6px;
}
.gove-sec-style{
	    margin: 2px;
      border-bottom: 1px solidrgb(255, 231, 231);
    padding: 3px;
}
.gallery-head-style{
    font-size: 28px;
    color: #4b4848;
    margin-bottom: 5px;
    border: 1px solid #cfcfcf;
    padding-bottom: 10px;
    padding-top: 15px;
    padding-left: 15px;
    background: red;
    /* color: white; */
    background: white;
    border: none;
    padding: 2px 0px;
}
/* GALLERY SECTION ENDS */
/* RECRUITER SECTION STARTS */
.recruiter-head-style{
	font-size: 28px;color: #4b4848;margin-bottom: 5px;
}
.recruiter-marquee{
	height: 100px;
}
.recruiter-marquee img{
	height:80px; width:140px;
}
/* RECRUITER SECTION ENDS */

/* PRODUCT-SECTION STARTS */
.footer {
	background: #232F3E;
	padding: 50px 0px;
}
.quicklink-menu {
	list-style:none;
	padding-left: 10px;
}
.quicklink-menu li a {
	color: #fff;
	line-height: 2.5;
	font-size: 15px;
	text-decoration:none;
}
.social-media {
	list-style:none;
	margin-top:10px;
}
.social-media li a img {
	width:30px;
}
.social-media li {
	float:left;
	padding:0px 8px;
}
.quicklink-heading {
	font-size:18px;
	font-weight:bold;
	color:#fff;
	margin-bottom:10px;
}
.get-in-touch {
	list-style:none;
	padding-left: 10px;
}
.get-in-touch li i {
	color: #ed372c;
	font-size: 20px;
}
.get-in-touch li {
	color: #fff;
	line-height: 2.5;
	font-size: 15px;
	text-decoration:none;
}
.footer-e-mail {
	font-size:15px;
	font-weight:bold;
	color:#fff;
	text-decoration:none;
}
.footer-website {
	font-size:12px;
	font-weight:bold;
	color:#fff;
	text-decoration:none;
}
.footer2-bacbor {
	background: #232F3E;
	padding:10px 0px;
	border-top: 1px solid #898989;
}
.footer2-content {
	font-size:14px;
	color:#000000;
	text-align:center;
}
/* PRODUCT-SECTION ENDS */

  </style>
</head>

<body>

  <div class="width-100 header-menu">
    <div class="container">
      <div class="logo">
        <img src="{{ asset('images/logo.png') }}" alt="Logo">
      </div>
      <ul class="main-menu">
        <li><a href="{{ route('about') }}">About Kantin</a></li>
        <li><a href="{{ route('list') }}">Cafeteria List</a></li>
        <li><a href="#">How to Buy</a></li>
        <li><a href="{{ route('contact') }}">Contact us</a></li>
      </ul>
    </div>
  </div>

  <div class="width-100">
    <img class="slider-width slider" src="{{ asset('images/slider.png') }}" alt="Slider">
  </div>

<form id="orderForm">
  @csrf
  @foreach($makanan as $item)
    <div class="event-date">
      <label for="item_{{ $item->id }}">
        {{ $item->nama }} (Rp {{ number_format($item->harga, 0, ',', '.') }}) (Stok sisa: {{ $item->stok }})
      </label><br>
      <input
        type="number"
        id="item_{{ $item->id }}"
        name="items[{{ $item->id }}]"
        min="0"
        max="{{ $item->stok }}"
        data-name="{{ $item->nama }}"
        data-price="{{ $item->harga }}"
        value="0"
      ><br>
      <p for="item_{{ $item->id }}">{{$item->kantin_asal}}</p>
    </div>
  @endforeach
    <div class="gove-sec-style">
  <input type="submit" value="  Beli  ">
  </div>
</form>
<script>
  document.getElementById('orderForm').addEventListener('submit', async function(event) {
    event.preventDefault();
    
    const form = event.target;
    const inputs = form.querySelectorAll('input[type="number"]');
    const data = {};
    let receipt = "Struk Pembelian:\n\n";
    let total = 0;
    let bought = false;

    inputs.forEach(input => {
      const id = input.name.match(/\d+/)[0];
      const qty = parseInt(input.value) || 0;

      if (qty > 0) {
        const name = input.dataset.name;
        const price = parseInt(input.dataset.price);
        const subtotal = qty * price;

        receipt += `- ${name} x${qty} = Rp ${subtotal.toLocaleString('id-ID')}\n`;
        total += subtotal;
        bought = true;

        data[id] = qty;
      }
    });

    if (!bought) {
      alert("Anda belum memesan apa pun.");
      return;
    }

    try {
      const response = await fetch("{{ route('buy.process') }}", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "X-CSRF-TOKEN": "{{ csrf_token() }}"
        },
        body: JSON.stringify({ items: data })
      });

      const result = await response.json();

      if (response.ok) {
        receipt += `\nTotal: Rp ${total.toLocaleString('id-ID')}`;
        alert(receipt);

        // ✅ Update stok on the page
        inputs.forEach(input => {
          const id = input.name.match(/\d+/)[0];
          const qty = parseInt(input.value) || 0;
          if (qty > 0) {
            const label = form.querySelector(`label[for="item_${id}"]`);
            const stokText = label.textContent.match(/Stok sisa: (\d+)/);
            if (stokText) {
              const oldStok = parseInt(stokText[1]);
              const newStok = oldStok - qty;
              label.textContent = label.textContent.replace(/Stok sisa: \d+/, `Stok sisa: ${newStok}`);
              input.max = newStok; // update max limit
            }
            input.value = 0; // reset input
          }
        });

      } else {
        alert("Terjadi kesalahan: " + result.message);
      }
    } catch (error) {
      alert("Gagal mengirim pesanan. Silakan coba lagi.");
      console.error(error);
    }
  });
</script>


  
  <div class="width-100 footer2-bacbor">
    <p class="footer2-content">Copyright © 2025, Aidan Syahm Hairuman.</p>
  </div>

</body>
</html>
