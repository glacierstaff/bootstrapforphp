<?php

namespace App\Http\Controllers;

use App\Models\Makanan;
use Illuminate\Http\Request;

class BuyController extends Controller
{


public function process(Request $request)
{
    $items = $request->input('items'); // associative array: id => quantity

    foreach ($items as $id => $qty) {
        $item = Makanan::find($id);

        if (!$item || $qty > $item->stok) {
            return response()->json(['message' => 'Stok tidak cukup untuk ' . ($item->nama ?? 'item')], 400);
        }

        $item->stok -= $qty;
        $item->save();
    }

    return response()->json(['message' => 'Pesanan berhasil diproses']);
}

}
