<?php

namespace App\Http\Controllers;
use App\Models\Makanan;

abstract class Controller
{
    public function showForm()
{
    $makanan = Makanan::all();
    return view('buy', compact('makanan'));
}

}
