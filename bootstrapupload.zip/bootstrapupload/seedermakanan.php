<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class seedermakanan extends Seeder
{
    /**
     * Run the database seeds.
     */
   public function run()
{
    DB::table('makanan')->insert([
        ['nama' => 'Batagor Campur Kecil', 'kantin_asal' => 'Kantin Batagor', 'harga' => 5000, 'stok' => 20, 'created_at' => now(), 'updated_at' => now()],
        ['nama' => 'Siomay Campur', 'kantin_asal' => 'Kantin Batagor', 'harga' => 10000, 'stok' => 10, 'created_at' => now(), 'updated_at' => now()],
        ['nama' => 'Batagor Campur', 'kantin_asal' => 'Kantin Batagor', 'harga' => 10000, 'stok' => 10, 'created_at' => now(), 'updated_at' => now()],
        ['nama' => 'Batagor Campur Extra', 'kantin_asal' => 'Kantin Batagor', 'harga' => 15000, 'stok' => 5, 'created_at' => now(), 'updated_at' => now()],

        ['nama' => 'Kentang Goreng', 'kantin_asal' => 'Kantin Indomie', 'harga' => 5000, 'stok' => 25, 'created_at' => now(), 'updated_at' => now()],
        ['nama' => 'Beef', 'kantin_asal' => 'Kantin Indomie', 'harga' => 10000, 'stok' => 10, 'created_at' => now(), 'updated_at' => now()],
        ['nama' => 'Indomie', 'kantin_asal' => 'Kantin Indomie', 'harga' => 8000, 'stok' => 15, 'created_at' => now(), 'updated_at' => now()],
        ['nama' => 'Indomie + Telur', 'kantin_asal' => 'Kantin Indomie', 'harga' => 11000, 'stok' => 15, 'created_at' => now(), 'updated_at' => now()],

        ['nama' => 'Ayam Katsu', 'kantin_asal' => 'Kantin Katsu', 'harga' => 10000, 'stok' => 15, 'created_at' => now(), 'updated_at' => now()],
        ['nama' => 'Nasi Ayam Katsu', 'kantin_asal' => 'Kantin Katsu', 'harga' => 10000, 'stok' => 15, 'created_at' => now(), 'updated_at' => now()],
        ['nama' => 'Nasi Ayam Richeese', 'kantin_asal' => 'Kantin Katsu', 'harga' => 10000, 'stok' => 15, 'created_at' => now(), 'updated_at' => now()],
        ['nama' => 'Risol', 'kantin_asal' => 'Kantin Katsu', 'harga' => 10000, 'stok' => 15, 'created_at' => now(), 'updated_at' => now()],
    ]);
}
}
